function loadAllEmployees() {
    console.log("got into loadAllEmployees")
    $.ajax({
        url: "/loadAllEmployees",
        success: function (data) {
            console.log("loadAllEmployees success : " + JSON.parse(res))
            var res = JSON.parse(data);
            $(res).each(
                function () {
                    var vals = JSON.parse(res);

                    $("#mid").append(
                        "<div class='getOut'>" +
                        "<p>id</p>" +
                        "<p>name</p>" +
                        "<p>salary</p>" +
                        "</div>"
                    );

                    $("#mid").append(
                        "<div class='getOut'>" +
                        "<p>" + vals.emp_id + "</p>" +
                        "<p>" + vals.name + "</p>" +
                        "<p>" + vals.salary + "</p>" +
                        " </div>"
                    );

/*                    vals.jobs.each(

                        $("#mid").append(
                            "<div class='getOut'>" +
                            "<p>job id</p>" +
                            "<p>description</p>" +
                            "<p>end date</p>" +
                            "</div>"
                        );

                        $("#mid").append(
                            "<div class='getOut'>" +
                            "<p>" + this.id + "</p>" +
                            "<p>" + this.description + "</p>" +
                            "<p>" + this.endDate + "</p>" +
                            "</div>"
                        );

                    );*/

                }
            )
        },
        fail: function (err) {
            alert('Error Accured During Extraction:' + err);
        },
        error: alert("error")
    });
}
