
function moveToSearch(){
    if (currentPage == 3){
        return;
    }

    $("#top").text("search");
    $("#top").append("<p style='font-size:20px; margin: 0;'>*by id or name</p>");

    $("#mid").text("");
    currentPage=3;
}

function moveToAbout(){
    if (currentPage == 4){
        return;
    }

    $("#top").text("about");
    $("#top").append("<p style='font-size:20px; margin: 0;'>this project</p>");

    $("#mid").text("");
    $("#mid").append("<p style='font-size:20px'>Alice's Adventures in Wonderland (commonly shortened to Alice in Wonderland)<br> is an 1865 novel written by English author Charles Lutwidge Dodgson under the pseudonym Lewis Carroll.<br> It tells of a young girl named Alice falling through a rabbit hole<br> into a fantasy world populated by peculiar, anthropomorphic creatures. <br>The tale plays with logic, giving the story lasting popularity with adults as well as with children.<br> It is considered to be one of the best examples of the literary nonsense genre.<br><br>One of the best-known and most popular works of English-language fiction,<br> its narrative course, structure, characters,<br> and imagery have been enormously influential in both popular culture and literature,<br> especially in the fantasy genre.<br> The work has never been out of print, and it has been translated into at least 97 languages.<br> Its ongoing legacy encompasses many adaptations for stage,<br> screen, radio, art, theme parks, board games, and video games.</p>");
    currentPage=4;
}
