package edu.test.beans.controllers;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import edu.test.beans.Company;
import edu.test.beans.entities.Employee;
import edu.test.beans.entities.Job;

@Controller
public class CompanyController {

	@Autowired
	private Company c;

	@RequestMapping(value = "/")
	public String home() {
		return "index.html";
	}

	@RequestMapping(value = "/loadAllEmployees")
	@ResponseBody
	public String loadAll() {

		JsonArray arr = new JsonArray();
		Gson formatter = new Gson();

		for (Employee employee : c.getAllEmployees()) {
			arr.add(formatter.toJson(employee));
			System.out.println("loading employee: " + employee.toString());
		}
		
		System.out.println(arr.toString());
		
		return arr.toString();
	}

	@RequestMapping(value = "/save")
	@ResponseBody
	public String save(@RequestParam(value="jsonString") String emp) {
		
		System.out.println(emp);
		return null;
	}
	
	
	/*
	 * @RequestMapping(value = "/save")
	 * 
	 * @ResponseBody public String save(@RequestParam(value="jsonString") String
	 * all) {
	 * 
	 * String [] arr = all.split(",");
	 * 
	 * double salary;
	 * 
	 * try { salary = Double.parseDouble(arr[1]); } catch(Exception e) { return
	 * "wrong salary value "+arr[1]+" in place 1"; };
	 * 
	 * List<Job> jobs = new ArrayList<Job>(2); for (int i = 2 ; i < arr.length ;
	 * i+=2) {
	 * 
	 * Job job = new Job();
	 * 
	 * for(int j = i ; j < i+2 ; j++) { if(j % 2 == 0) { job.setDescription(arr[j]);
	 * } else { try {job.setEndDate(Date.valueOf(arr[j]));} catch(Exception e) {
	 * return "wrong date format "+arr[j]+" in place "+j;} }
	 * 
	 * }
	 * 
	 * jobs.add(job);
	 * 
	 * }
	 * 
	 * c.addEmployee(new Employee(arr[0], salary, jobs)); return "true"; }
	 */
	
	@RequestMapping(value = "/searchId")
	@ResponseBody
	public String search(@RequestParam long id) {
		return null;
	}

	@RequestMapping(value = "/searchName")
	@ResponseBody
	public String search(@RequestParam String name) {
		return null;
	}

}