package edu.test.beans.factory;

public class EmployeeFactory {

}
