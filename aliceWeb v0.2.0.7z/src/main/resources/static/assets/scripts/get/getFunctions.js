function loadAllEmployees() {

    console.log("got into loadAllEmployees")
    $.ajax({
        url: "/loadAllEmployees",
        success: function (data) {

            console.log(data);

            var empArr = JSON.parse(data);

            empArr.forEach(function(emp){

                    $("#mid").append(
                        "<div class='getOut headGet'>" +
                        "<p>id</p>" +
                        "<p>name</p>" +
                        "<p>salary</p>" +
                        "</div>"
                    );

                    $("#mid").append(
                        "<div class='getOut '>" +
                        "<p>" + emp.emp_id + "</p>" +
                        "<p>" + emp.name + "</p>" +
                        "<p>" + emp.salary + "</p>" +
                        " </div>"
                    );

                    emp.jobs.forEach(function(job){

                       $("#mid").append(
                            "<div class='getOut headGet'>" +
                            "<p>job id</p>" +
                            "<p>description</p>" +
                            "<p>end date</p>" +
                            "</div>"
                        );

                        $("#mid").append(
                            "<div class='getOut'>" +
                            "<p>" + job.id + "</p>" +
                            "<p>" + job.description + "</p>" +
                            "<p>" + job.endDate + "</p>" +
                            "</div>"
                        );
                    })

            });

        },
        fail: function (err) {
            console.log(err);
            errorFunction();
        },
        error: function(err){
            console.log(err);
            errorFunction();
        }
    });
}

