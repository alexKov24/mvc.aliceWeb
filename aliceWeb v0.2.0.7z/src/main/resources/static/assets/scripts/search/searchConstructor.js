function moveToSearch(){


    $("#top").text("search");
    $("#top").append("<p style='font-size:20px; margin: 0;'>*by id or name</p>");

    $("#mid").text("");

    checkConnection(addSearch());

}

function addSearch(){
    $("#mid").append(
        "<div class='searchBlock' >"+
        "<input class='search' value='search' onmouseenter='toggleText(this)' onmouseleave='toggleText(this)' >"+
        "<button id='searchButton' onclick='search()'>search</button>"+
        "<p class='hint'></p>"+

        "</div>"
    );
}
