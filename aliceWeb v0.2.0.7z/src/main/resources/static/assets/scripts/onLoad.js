$(function() {

    moveToAbout();//constructor - loads about page

    makeAlice();//alice - split and load

});
